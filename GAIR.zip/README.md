# GAIR 

This file contains the implementation code for GAIR, submission to Neurips 2025.

The core components of this implementation are:

main_pretrain.py: This file contains the main training pipeline for the GAIR model.

model_cl_RS_sc.py: This file defines the architecture and forward pass of the GAIR model itself.



